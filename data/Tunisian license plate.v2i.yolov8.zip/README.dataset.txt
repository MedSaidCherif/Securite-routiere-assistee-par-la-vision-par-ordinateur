# Tunisian license plate > 2023-12-08 10:27pm
https://universe.roboflow.com/adel-hachicha-fiyf1/tunisian-license-plate

Provided by a Roboflow user
License: MIT

